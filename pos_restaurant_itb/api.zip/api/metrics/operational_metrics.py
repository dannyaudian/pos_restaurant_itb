# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
Operational Metrics API
---------------------
Real-time and historical operational metrics for restaurant management.

Features:
- Real-time performance monitoring
- Historical data analysis
- Comparative metrics
- Efficiency indicators
- Resource utilization tracking
"""

__created_date__ = '2025-04-06 15:53:12'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List, Optional, Union
from datetime import datetime, timedelta

from pos_restaurant_itb.utils.error_handlers import handle_api_error, MetricsError
from pos_restaurant_itb.utils.security import validate_metrics_access
from pos_restaurant_itb.utils.constants import MetricsType

@frappe.whitelist()
@handle_api_error
def get_realtime_metrics(branch: Optional[str] = None) -> Dict:
    """
    Get real-time operational metrics
    
    Args:
        branch: Optional branch filter
        
    Returns:
        Dict containing current operational metrics
    """
    try:
        validate_metrics_access("view_realtime_metrics")
        current_time = frappe.utils.now_datetime()
        
        metrics = {
            "timestamp": current_time,
            "orders": get_order_metrics(current_time, branch),
            "kitchen": get_kitchen_metrics(current_time, branch),
            "tables": get_table_metrics(branch),
            "staff": get_staff_metrics(current_time, branch),
            "revenue": get_revenue_metrics(current_time, branch)
        }
        
        # Calculate performance indicators
        metrics["indicators"] = calculate_performance_indicators(metrics)
        
        return {
            "success": True,
            "metrics": metrics,
            "branch": branch or "All Branches",
            "refresh_interval": get_refresh_interval()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Realtime Metrics Error: {str(e)}\n{frappe.get_traceback()}",
            title="Operational Metrics Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def get_comparative_analysis(
    metric_type: str,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    compare_with: Optional[str] = None,
    branch: Optional[str] = None
) -> Dict:
    """
    Get comparative analysis of metrics
    
    Args:
        metric_type: Type of metric to analyze
        start_date: Analysis start date
        end_date: Analysis end date
        compare_with: Period to compare with (previous_period/last_year)
        branch: Optional branch filter
        
    Returns:
        Dict containing comparative analysis
    """
    try:
        validate_metrics_access("view_comparative_analysis")
        
        # Validate metric type
        if metric_type not in MetricsType.__members__:
            raise MetricsError(f"Invalid metric type: {metric_type}")
            
        # Set default dates
        end_date = end_date or frappe.utils.today()
        start_date = start_date or frappe.utils.add_days(end_date, -30)
        
        # Get current period data
        current_data = get_metric_data(
            metric_type, start_date, end_date, branch
        )
        
        # Get comparison period data
        comparison_data = None
        if compare_with:
            comp_start, comp_end = get_comparison_dates(
                start_date, end_date, compare_with
            )
            comparison_data = get_metric_data(
                metric_type, comp_start, comp_end, branch
            )
            
        # Calculate variances
        variances = calculate_variances(
            current_data, comparison_data
        ) if comparison_data else None
        
        return {
            "success": True,
            "metric_type": metric_type,
            "current_period": {
                "start_date": start_date,
                "end_date": end_date,
                "data": current_data
            },
            "comparison_period": {
                "start_date": comp_start if compare_with else None,
                "end_date": comp_end if compare_with else None,
                "data": comparison_data
            },
            "variances": variances,
            "branch": branch or "All Branches"
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Comparative Analysis Error: {str(e)}\n{frappe.get_traceback()}",
            title="Analysis Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def export_metrics_report(
    report_type: str,
    start_date: str,
    end_date: str,
    branch: Optional[str] = None,
    format: str = "Excel"
) -> Dict:
    """
    Export metrics report in various formats
    
    Args:
        report_type: Type of report to generate
        start_date: Report start date
        end_date: Report end date
        branch: Optional branch filter
        format: Export format (Excel/PDF/CSV)
        
    Returns:
        Dict containing report file information
    """
    try:
        validate_metrics_access("export_reports")
        
        # Validate dates
        if frappe.utils.getdate(start_date) > frappe.utils.getdate(end_date):
            raise MetricsError("Start date cannot be after end date")
            
        # Generate report data
        report_data = generate_report_data(
            report_type, start_date, end_date, branch
        )
        
        # Export in specified format
        file_url = export_report(
            report_data, format, f"{report_type}_{start_date}_{end_date}"
        )
        
        return {
            "success": True,
            "file_url": file_url,
            "report_type": report_type,
            "format": format,
            "start_date": start_date,
            "end_date": end_date,
            "branch": branch or "All Branches"
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Report Export Error: {str(e)}\n{frappe.get_traceback()}",
            title="Export Error"
        )
        return {"success": False, "error": str(e)}

def get_order_metrics(current_time: datetime, branch: Optional[str]) -> Dict:
    """Get current order related metrics"""
    filters = {"docstatus": 1}
    if branch:
        filters["branch"] = branch
        
    return {
        "total_orders": frappe.db.count(
            "POS Order",
            filters={
                **filters,
                "creation": [">=", current_time.date()]
            }
        ),
        "active_orders": frappe.db.count(
            "POS Order",
            filters={
                **filters,
                "status": ["in", ["Draft", "To Bill", "Unpaid"]]
            }
        ),
        "avg_preparation_time": get_avg_preparation_time(current_time, branch),
        "order_distribution": get_order_distribution(current_time, branch)
    }

def get_kitchen_metrics(current_time: datetime, branch: Optional[str]) -> Dict:
    """Get current kitchen performance metrics"""
    return {
        "active_kot": get_active_kot_count(branch),
        "station_load": get_station_load(branch),
        "preparation_queue": get_preparation_queue(branch),
        "efficiency_scores": get_station_efficiency_scores(branch)
    }

def calculate_performance_indicators(metrics: Dict) -> Dict:
    """Calculate key performance indicators"""
    return {
        "operational_efficiency": calculate_operational_efficiency(metrics),
        "resource_utilization": calculate_resource_utilization(metrics),
        "customer_satisfaction": calculate_customer_satisfaction(metrics),
        "revenue_performance": calculate_revenue_performance(metrics)
    }

def get_refresh_interval() -> int:
    """Get metrics refresh interval from settings"""
    settings = frappe.get_single("POS Restaurant Config")
    return settings.metrics_refresh_interval or 60  # Default 60 seconds