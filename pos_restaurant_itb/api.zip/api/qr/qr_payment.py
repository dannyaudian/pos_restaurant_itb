# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
QR Payment API
-------------
Handles QR-based payment processing for restaurant orders.

Features:
- Generate payment QR codes
- Validate payments
- Process refunds
- Payment status tracking
"""

__created_date__ = '2025-04-06 15:45:26'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, Optional
from datetime import datetime

from pos_restaurant_itb.utils.error_handlers import handle_api_error, QRError
from pos_restaurant_itb.utils.security import validate_payment_permission
from pos_restaurant_itb.utils.constants import PaymentStatus

@frappe.whitelist()
@handle_api_error
def generate_payment_qr(order_id: str, amount: float) -> Dict:
    """
    Generate QR code for payment
    
    Args:
        order_id: POS Order ID
        amount: Payment amount
        
    Returns:
        Dict containing:
            - success: Boolean indicating success/failure
            - qr_data: QR code data
            - payment_id: Generated payment ID
            - expiry: QR code expiry time
    """
    try:
        # Validate order
        order = frappe.get_doc("POS Order", order_id)
        if not order:
            raise QRError("Invalid order ID")
            
        # Validate amount
        if amount <= 0 or amount > order.grand_total:
            raise QRError("Invalid payment amount")
            
        # Get payment gateway settings
        settings = frappe.get_single("POS Restaurant Config")
        if not settings.enable_qr_payments:
            raise QRError("QR payments are not enabled")
            
        # Generate payment entry
        payment = frappe.get_doc({
            "doctype": "QR Payment Entry",
            "order": order_id,
            "amount": amount,
            "status": PaymentStatus.PENDING,
            "gateway": settings.qr_payment_gateway,
            "expiry": frappe.utils.add_minutes(
                frappe.utils.now(), 
                settings.qr_expiry_minutes or 15
            )
        })
        payment.insert()
        
        # Generate QR code
        qr_data = generate_qr_data(payment)
        
        return {
            "success": True,
            "payment_id": payment.name,
            "qr_data": qr_data,
            "expiry": payment.expiry,
            "amount": amount
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"QR Payment Generation Error: {str(e)}\n{frappe.get_traceback()}",
            title="QR Payment Error"
        )
        return {
            "success": False,
            "error": str(e),
            "error_type": type(e).__name__
        }

@frappe.whitelist()
@handle_api_error
def verify_payment(payment_id: str) -> Dict:
    """
    Verify payment status
    
    Args:
        payment_id: QR Payment Entry ID
        
    Returns:
        Dict containing payment verification status
    """
    try:
        payment = frappe.get_doc("QR Payment Entry", payment_id)
        
        # Check expiry
        if frappe.utils.now() > payment.expiry:
            payment.status = PaymentStatus.EXPIRED
            payment.save()
            raise QRError("Payment QR code has expired")
            
        # Check with payment gateway
        gateway_response = check_payment_gateway(payment)
        
        if gateway_response.get("status") == "success":
            complete_payment(payment, gateway_response)
            
        return {
            "success": True,
            "status": payment.status,
            "transaction_id": gateway_response.get("transaction_id"),
            "verified_amount": gateway_response.get("amount"),
            "verification_time": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Payment Verification Error: {str(e)}\n{frappe.get_traceback()}",
            title="Payment Verification Error"
        )
        return {
            "success": False,
            "error": str(e),
            "error_type": type(e).__name__
        }

def generate_qr_data(payment) -> str:
    """Generate QR code data based on payment gateway"""
    gateway_settings = frappe.get_doc(
        "Payment Gateway", 
        payment.gateway
    )
    
    return gateway_settings.generate_qr_data({
        "amount": payment.amount,
        "reference": payment.name,
        "expiry": payment.expiry,
        "order": payment.order
    })

def check_payment_gateway(payment) -> Dict:
    """Check payment status with payment gateway"""
    gateway_settings = frappe.get_doc(
        "Payment Gateway", 
        payment.gateway
    )
    
    return gateway_settings.check_payment_status(payment.name)

def complete_payment(payment, gateway_response) -> None:
    """Complete payment processing"""
    payment.status = PaymentStatus.COMPLETED
    payment.transaction_id = gateway_response.get("transaction_id")
    payment.gateway_response = frappe.as_json(gateway_response)
    payment.completion_time = frappe.utils.now()
    payment.save()
    
    # Update order payment status
    order = frappe.get_doc("POS Order", payment.order)
    order.payment_status = "Paid"
    order.save()
    
    # Send notifications
    notify_payment_completion(payment)

def notify_payment_completion(payment) -> None:
    """Send payment completion notifications"""
    frappe.publish_realtime(
        "payment_completed",
        {
            "payment_id": payment.name,
            "order": payment.order,
            "amount": payment.amount
        },
        user=frappe.session.user
    )