# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

__created_date__ = '2025-04-06 15:39:04'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List

@frappe.whitelist()
def create_qr_order(session_id: str, items: List[Dict]) -> Dict:
    """Create new order from QR session"""
    try:
        validate_session(session_id)
        order = create_order_document(session_id, items)
        
        return {
            "success": True,
            "order_id": order.name,
            "estimated_time": calculate_prep_time(items)
        }
    except Exception as e:
        frappe.log_error(str(e), "QR Order Creation Error")
        return {"success": False, "error": str(e)}
