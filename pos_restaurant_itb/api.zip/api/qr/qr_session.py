# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

__created_date__ = '2025-04-06 15:39:04'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, Optional

@frappe.whitelist()
def create_qr_session(table: str) -> Dict:
    """Create new QR ordering session for table"""
    try:
        validate_table(table)
        session = frappe.get_doc({
            "doctype": "QR Session",
            "table": table,
            "status": "Active",
            "creation": frappe.utils.now()
        })
        session.insert()
        
        return {
            "success": True,
            "session_id": session.name,
            "qr_code": generate_qr_code(session.name)
        }
    except Exception as e:
        frappe.log_error(str(e), "QR Session Creation Error")
        return {"success": False, "error": str(e)}
