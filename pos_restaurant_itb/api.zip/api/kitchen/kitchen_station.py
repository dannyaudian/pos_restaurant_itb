# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
Kitchen Station Management API
---------------------------
Manages kitchen station operations, configuration, and monitoring.

Features:
- Station configuration
- Workload management
- Staff assignment
- Equipment tracking
- Performance monitoring
"""

__created_date__ = '2025-04-06 15:59:12'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List, Optional, Union
from datetime import datetime, timedelta

from pos_restaurant_itb.utils.error_handlers import handle_api_error, StationError
from pos_restaurant_itb.utils.constants import StationStatus, EquipmentStatus

@frappe.whitelist()
@handle_api_error
def get_station_status(station: Optional[str] = None) -> Dict:
    """
    Get kitchen station status and metrics
    
    Args:
        station: Optional specific station name
        
    Returns:
        Dict containing station status and metrics
    """
    try:
        filters = {"disabled": 0}
        if station:
            filters["name"] = station
            
        stations = frappe.get_all(
            "Kitchen Station",
            filters=filters,
            fields=[
                "name",
                "station_name",
                "status",
                "capacity",
                "current_load",
                "equipment_status",
                "staff_assigned",
                "last_maintenance",
                "maintenance_due"
            ]
        )
        
        # Enrich station data
        for station in stations:
            station.metrics = get_station_metrics(station.name)
            station.equipment = get_station_equipment(station.name)
            station.staff = get_assigned_staff(station.name)
            station.active_orders = get_active_orders(station.name)
            
        return {
            "success": True,
            "stations": stations,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Station Status Error: {str(e)}\n{frappe.get_traceback()}",
            title="Station Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def update_station_status(
    station: str,
    status: str,
    reason: Optional[str] = None
) -> Dict:
    """
    Update kitchen station status
    
    Args:
        station: Station name
        status: New status
        reason: Optional status change reason
        
    Returns:
        Dict containing updated station status
    """
    try:
        # Validate status
        if status not in StationStatus.__members__:
            raise StationError(f"Invalid status: {status}")
            
        # Get station
        station_doc = frappe.get_doc("Kitchen Station", station)
        
        # Check if status change is allowed
        validate_status_change(station_doc, status)
        
        # Update status
        old_status = station_doc.status
        station_doc.status = status
        if reason:
            station_doc.status_change_reason = reason
        station_doc.last_status_change = frappe.utils.now()
        station_doc.save()
        
        # Log status change
        log_status_change(station_doc, old_status, status, reason)
        
        # Handle status-specific actions
        handle_status_change_actions(station_doc, old_status)
        
        return {
            "success": True,
            "station": station,
            "status": status,
            "timestamp": frappe.utils.now(),
            "metrics": get_station_metrics(station)
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Station Status Update Error: {str(e)}\n{frappe.get_traceback()}",
            title="Station Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def assign_staff(
    station: str,
    staff_id: str,
    role: str,
    shift: str
) -> Dict:
    """
    Assign staff to kitchen station
    
    Args:
        station: Station name
        staff_id: Staff ID to assign
        role: Staff role at station
        shift: Work shift
        
    Returns:
        Dict containing assignment status
    """
    try:
        # Validate staff
        if not frappe.db.exists("Employee", staff_id):
            raise StationError(f"Invalid staff ID: {staff_id}")
            
        # Create assignment
        assignment = frappe.get_doc({
            "doctype": "Station Staff Assignment",
            "station": station,
            "staff": staff_id,
            "role": role,
            "shift": shift,
            "start_time": frappe.utils.now()
        })
        assignment.insert()
        
        # Update station staff count
        update_station_staff_count(station)
        
        # Notify assignment
        notify_staff_assignment(assignment)
        
        return {
            "success": True,
            "assignment_id": assignment.name,
            "station": station,
            "staff_id": staff_id,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Staff Assignment Error: {str(e)}\n{frappe.get_traceback()}",
            title="Station Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def update_equipment_status(
    station: str,
    equipment_id: str,
    status: str,
    notes: Optional[str] = None
) -> Dict:
    """
    Update station equipment status
    
    Args:
        station: Station name
        equipment_id: Equipment ID
        status: New equipment status
        notes: Optional status notes
        
    Returns:
        Dict containing equipment status update
    """
    try:
        # Validate status
        if status not in EquipmentStatus.__members__:
            raise StationError(f"Invalid equipment status: {status}")
            
        # Get equipment
        equipment = frappe.get_doc("Station Equipment", equipment_id)
        
        # Update status
        old_status = equipment.status
        equipment.status = status
        if notes:
            equipment.status_notes = notes
        equipment.last_status_update = frappe.utils.now()
        equipment.save()
        
        # Log status change
        log_equipment_status(equipment, old_status, status, notes)
        
        # Check station operational status
        check_station_operational_status(station)
        
        return {
            "success": True,
            "equipment_id": equipment_id,
            "status": status,
            "station": station,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Equipment Status Update Error: {str(e)}\n{frappe.get_traceback()}",
            title="Station Error"
        )
        return {"success": False, "error": str(e)}

def get_station_metrics(station: str) -> Dict:
    """Calculate station performance metrics"""
    return {
        "order_completion_rate": calculate_completion_rate(station),
        "avg_preparation_time": get_avg_prep_time(station),
        "current_efficiency": calculate_current_efficiency(station),
        "workload_distribution": get_workload_distribution(station),
        "equipment_utilization": calculate_equipment_utilization(station)
    }

def validate_status_change(
    station: "Kitchen Station",
    new_status: str
) -> None:
    """Validate if status change is allowed"""
    if station.status == StationStatus.MAINTENANCE:
        if new_status != StationStatus.OPERATIONAL:
            raise StationError(
                "Station in maintenance can only be changed to operational"
            )
    
    if new_status == StationStatus.OFFLINE:
        active_orders = get_active_orders(station.name)
        if active_orders:
            raise StationError(
                "Cannot set station offline with active orders"
            )

def handle_status_change_actions(
    station: "Kitchen Station",
    old_status: str
) -> None:
    """Handle actions required for status changes"""
    if station.status == StationStatus.MAINTENANCE:
        reassign_active_orders(station.name)
        notify_maintenance_schedule(station)
    elif station.status == StationStatus.OPERATIONAL:
        if old_status == StationStatus.MAINTENANCE:
            verify_equipment_status(station)
            update_maintenance_records(station)