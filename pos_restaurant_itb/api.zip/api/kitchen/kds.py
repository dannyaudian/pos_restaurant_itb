# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
Kitchen Display System (KDS) API
------------------------------
Manages kitchen display system operations and order flow.

Features:
- Order management
- Station assignment
- Real-time updates
- Priority handling
- SLA tracking
"""

__created_date__ = '2025-04-06 15:57:31'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List, Optional, Union
from datetime import datetime, timedelta

from pos_restaurant_itb.utils.error_handlers import handle_api_error, KDSError
from pos_restaurant_itb.utils.common import get_business_date
from pos_restaurant_itb.utils.constants import KDSStatus, OrderPriority

@frappe.whitelist()
@handle_api_error
def get_station_orders(
    station: str,
    status: Optional[List[str]] = None,
    order_type: Optional[str] = None
) -> Dict:
    """
    Get orders for a specific kitchen station
    
    Args:
        station: Kitchen station name
        status: Optional list of order statuses to filter
        order_type: Optional order type filter
        
    Returns:
        Dict containing station orders and metrics
    """
    try:
        # Validate station
        if not frappe.db.exists("Kitchen Station", station):
            raise KDSError(f"Invalid station: {station}")
            
        # Build filters
        filters = {"kitchen_station": station}
        if status:
            filters["status"] = ["in", status]
        if order_type:
            filters["order_type"] = order_type
            
        # Get orders
        orders = frappe.get_all(
            "Kitchen Display Order",
            filters=filters,
            fields=[
                "name",
                "order_id",
                "table_no",
                "customer_name",
                "status",
                "priority",
                "order_time",
                "preparation_time",
                "completion_time",
                "notes",
                "order_type",
                "server_name"
            ],
            order_by="priority desc, order_time asc"
        )
        
        # Enrich orders with items and metrics
        for order in orders:
            order.items = get_order_items(order.name)
            order.metrics = calculate_order_metrics(order)
            
        # Get station metrics
        station_metrics = get_station_metrics(station)
        
        return {
            "success": True,
            "station": station,
            "orders": orders,
            "metrics": station_metrics,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"KDS Station Orders Error: {str(e)}\n{frappe.get_traceback()}",
            title="KDS Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def update_order_status(
    order_id: str,
    status: str,
    completion_time: Optional[str] = None,
    notes: Optional[str] = None
) -> Dict:
    """
    Update KDS order status
    
    Args:
        order_id: KDS order ID
        status: New status
        completion_time: Optional completion time
        notes: Optional status update notes
        
    Returns:
        Dict containing updated order status
    """
    try:
        # Validate status
        if status not in KDSStatus.__members__:
            raise KDSError(f"Invalid status: {status}")
            
        # Get order
        order = frappe.get_doc("Kitchen Display Order", order_id)
        
        # Update status
        order.status = status
        if status == KDSStatus.COMPLETED:
            order.completion_time = completion_time or frappe.utils.now()
            order.preparation_time = calculate_preparation_time(
                order.order_time,
                order.completion_time
            )
            
        if notes:
            order.notes = notes
            
        order.save()
        
        # Update POS order status
        update_pos_order_status(order)
        
        # Send notifications
        notify_status_update(order)
        
        return {
            "success": True,
            "order_id": order_id,
            "status": status,
            "timestamp": frappe.utils.now(),
            "metrics": calculate_order_metrics(order)
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"KDS Order Status Update Error: {str(e)}\n{frappe.get_traceback()}",
            title="KDS Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def reassign_station(
    order_id: str,
    new_station: str,
    reason: Optional[str] = None
) -> Dict:
    """
    Reassign order to different kitchen station
    
    Args:
        order_id: KDS order ID
        new_station: New station to assign
        reason: Optional reason for reassignment
        
    Returns:
        Dict containing reassignment status
    """
    try:
        # Validate station
        if not frappe.db.exists("Kitchen Station", new_station):
            raise KDSError(f"Invalid station: {new_station}")
            
        # Get order
        order = frappe.get_doc("Kitchen Display Order", order_id)
        
        # Store old station for notification
        old_station = order.kitchen_station
        
        # Update station
        order.kitchen_station = new_station
        if reason:
            order.reassignment_reason = reason
        order.reassignment_time = frappe.utils.now()
        order.save()
        
        # Log reassignment
        log_station_reassignment(order, old_station, new_station, reason)
        
        # Notify stations
        notify_station_reassignment(order, old_station)
        
        return {
            "success": True,
            "order_id": order_id,
            "new_station": new_station,
            "old_station": old_station,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Station Reassignment Error: {str(e)}\n{frappe.get_traceback()}",
            title="KDS Error"
        )
        return {"success": False, "error": str(e)}

def calculate_order_metrics(order: Dict) -> Dict:
    """Calculate metrics for an order"""
    current_time = frappe.utils.now_datetime()
    order_time = frappe.utils.get_datetime(order.order_time)
    
    elapsed_time = (current_time - order_time).total_seconds() / 60
    sla_time = get_order_sla_time(order)
    
    return {
        "elapsed_time": round(elapsed_time, 2),
        "sla_time": sla_time,
        "sla_status": "Warning" if elapsed_time > (sla_time * 0.8) else "Normal",
        "efficiency_score": calculate_efficiency_score(order),
        "priority_level": get_priority_level(order.priority)
    }

def notify_status_update(order: "Kitchen Display Order") -> None:
    """Send order status notifications"""
    # Notify POS
    frappe.publish_realtime(
        "kds_order_update",
        {
            "order_id": order.name,
            "status": order.status,
            "completion_time": order.completion_time
        }
    )
    
    # Notify kitchen stations
    frappe.publish_realtime(
        f"kds_station_{order.kitchen_station}",
        {
            "type": "status_update",
            "order_id": order.name,
            "status": order.status
        }
    )
    
    # Update digital menu boards if completed
    if order.status == KDSStatus.COMPLETED:
        update_menu_boards(order)