# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
Kitchen Order Ticket (KOT) Creation API
------------------------------------
Manages the creation and routing of kitchen order tickets.

Features:
- KOT generation
- Station routing
- Priority handling
- Order splitting
- Real-time notifications
"""

__created_date__ = '2025-04-06 16:06:37'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List, Optional, Union
from datetime import datetime, timedelta

from pos_restaurant_itb.utils.error_handlers import handle_api_error, KOTError
from pos_restaurant_itb.utils.security import validate_kot_permission
from pos_restaurant_itb.utils.constants import KOTStatus, OrderPriority

@frappe.whitelist()
@handle_api_error
def create_kot(
    order_id: str,
    items: List[Dict],
    priority: Optional[int] = None,
    notes: Optional[str] = None
) -> Dict:
    """
    Create new Kitchen Order Ticket
    
    Args:
        order_id: POS Order ID
        items: List of order items
        priority: Optional priority level
        notes: Optional kitchen notes
        
    Returns:
        Dict containing KOT details
    """
    try:
        # Validate permissions
        validate_kot_permission("create")
        
        # Validate order
        order = frappe.get_doc("POS Order", order_id)
        if not order:
            raise KOTError(f"Invalid order ID: {order_id}")
            
        # Group items by station
        station_items = group_items_by_station(items)
        
        # Create KOTs for each station
        kot_details = []
        for station, station_items in station_items.items():
            kot = create_station_kot(
                order,
                station,
                station_items,
                priority,
                notes
            )
            kot_details.append(kot)
            
        # Update order status
        update_order_kot_status(order_id)
        
        # Send notifications
        notify_kot_creation(kot_details)
        
        return {
            "success": True,
            "order_id": order_id,
            "kot_details": kot_details,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"KOT Creation Error: {str(e)}\n{frappe.get_traceback()}",
            title="KOT Error"
        )
        return {"success": False, "error": str(e)}

def create_station_kot(
    order: "POS Order",
    station: str,
    items: List[Dict],
    priority: Optional[int],
    notes: Optional[str]
) -> Dict:
    """Create KOT for specific station"""
    # Calculate KOT priority
    final_priority = calculate_kot_priority(
        order,
        priority or OrderPriority.NORMAL
    )
    
    # Create KOT document
    kot = frappe.get_doc({
        "doctype": "Kitchen Order Ticket",
        "order": order.name,
        "kitchen_station": station,
        "items": prepare_kot_items(items),
        "priority": final_priority,
        "notes": notes,
        "status": KOTStatus.PENDING,
        "order_time": frappe.utils.now(),
        "table_no": order.table_no,
        "customer_name": order.customer_name,
        "server_name": order.server_name
    })
    
    kot.insert()
    
    # Create KOT print job
    create_kot_print_job(kot)
    
    return {
        "kot_id": kot.name,
        "station": station,
        "priority": final_priority,
        "item_count": len(items)
    }

def group_items_by_station(items: List[Dict]) -> Dict[str, List[Dict]]:
    """Group order items by kitchen station"""
    station_items = {}
    
    for item in items:
        # Get item's assigned station
        station = get_item_station(item["item_code"])
        
        if station not in station_items:
            station_items[station] = []
            
        station_items[station].append(item)
        
    return station_items

def calculate_kot_priority(
    order: "POS Order",
    base_priority: int
) -> int:
    """Calculate final KOT priority"""
    priority = base_priority
    
    # Adjust for VIP customers
    if is_vip_customer(order.customer):
        priority += 1
        
    # Adjust for order type
    if order.order_type == "Takeaway":
        priority += 1
        
    # Adjust for waiting time
    if order.creation:
        wait_time = (frappe.utils.now_datetime() - order.creation).total_seconds() / 60
        if wait_time > 15:  # More than 15 minutes
            priority += 1
            
    return min(priority, OrderPriority.URGENT)

def prepare_kot_items(items: List[Dict]) -> List[Dict]:
    """Prepare items for KOT creation"""
    kot_items = []
    
    for item in items:
        kot_item = {
            "item_code": item["item_code"],
            "item_name": item["item_name"],
            "quantity": item["quantity"],
            "unit": item["unit"],
            "notes": item.get("notes", ""),
            "modifiers": prepare_item_modifiers(item.get("modifiers", [])),
            "allergies": item.get("allergies", []),
            "cooking_instructions": item.get("cooking_instructions", "")
        }
        
        kot_items.append(kot_item)
        
    return kot_items

def create_kot_print_job(kot: "Kitchen Order Ticket") -> None:
    """Create print job for KOT"""
    settings = frappe.get_single("POS Restaurant Config")
    
    if settings.enable_kot_printing:
        printer = get_station_printer(kot.kitchen_station)
        if printer:
            frappe.get_doc({
                "doctype": "Print Job",
                "printer": printer,
                "document_type": "Kitchen Order Ticket",
                "document_name": kot.name,
                "priority": kot.priority,
                "status": "Pending"
            }).insert()

def notify_kot_creation(kot_details: List[Dict]) -> None:
    """Send notifications for new KOTs"""
    # Notify kitchen displays
    for kot in kot_details:
        frappe.publish_realtime(
            f"new_kot_{kot['station']}",
            {
                "kot_id": kot["kot_id"],
                "priority": kot["priority"],
                "item_count": kot["item_count"]
            }
        )
    
    # Notify POS
    frappe.publish_realtime(
        "kot_created",
        {
            "kot_ids": [kot["kot_id"] for kot in kot_details]
        }
    )