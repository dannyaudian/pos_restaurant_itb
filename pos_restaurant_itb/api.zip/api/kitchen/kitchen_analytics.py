# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
Kitchen Analytics API
------------------
Advanced analytics and reporting for kitchen operations.

Features:
- Performance analytics
- Efficiency metrics
- Load balancing
- Trend analysis
- Predictive insights
"""

__created_date__ = '2025-04-06 16:04:33'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List, Optional, Union, Tuple
from datetime import datetime, timedelta
import json

from pos_restaurant_itb.utils.error_handlers import handle_api_error, AnalyticsError
from pos_restaurant_itb.utils.security import validate_analytics_access
from pos_restaurant_itb.utils.constants import AnalyticsMetrics, TimeIntervals

@frappe.whitelist()
@handle_api_error
def get_kitchen_performance(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    station: Optional[str] = None,
    metrics: Optional[List[str]] = None
) -> Dict:
    """
    Get comprehensive kitchen performance metrics
    
    Args:
        start_date: Analysis start date
        end_date: Analysis end date
        station: Optional station filter
        metrics: Optional specific metrics to calculate
        
    Returns:
        Dict containing performance metrics
    """
    try:
        validate_analytics_access("kitchen_performance")
        
        # Set default dates
        end_date = end_date or frappe.utils.today()
        start_date = start_date or frappe.utils.add_days(end_date, -30)
        
        # Validate metrics
        if metrics:
            invalid_metrics = [m for m in metrics if m not in AnalyticsMetrics.__members__]
            if invalid_metrics:
                raise AnalyticsError(f"Invalid metrics: {', '.join(invalid_metrics)}")
        
        # Get base data
        base_data = get_base_performance_data(start_date, end_date, station)
        
        # Calculate requested metrics
        calculated_metrics = calculate_performance_metrics(
            base_data,
            metrics or list(AnalyticsMetrics.__members__.keys())
        )
        
        # Get trends
        trends = analyze_performance_trends(base_data)
        
        return {
            "success": True,
            "start_date": start_date,
            "end_date": end_date,
            "station": station,
            "metrics": calculated_metrics,
            "trends": trends,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Kitchen Performance Analysis Error: {str(e)}\n{frappe.get_traceback()}",
            title="Analytics Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def get_efficiency_report(
    date: Optional[str] = None,
    interval: str = TimeIntervals.HOURLY
) -> Dict:
    """
    Get detailed efficiency report
    
    Args:
        date: Report date
        interval: Time interval for analysis
        
    Returns:
        Dict containing efficiency metrics
    """
    try:
        validate_analytics_access("efficiency_report")
        
        # Set default date
        date = date or frappe.utils.today()
        
        # Validate interval
        if interval not in TimeIntervals.__members__:
            raise AnalyticsError(f"Invalid interval: {interval}")
            
        # Get efficiency data
        efficiency_data = get_efficiency_data(date, interval)
        
        # Calculate KPIs
        kpis = calculate_efficiency_kpis(efficiency_data)
        
        # Get recommendations
        recommendations = generate_efficiency_recommendations(
            efficiency_data,
            kpis
        )
        
        return {
            "success": True,
            "date": date,
            "interval": interval,
            "efficiency_data": efficiency_data,
            "kpis": kpis,
            "recommendations": recommendations,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Efficiency Report Error: {str(e)}\n{frappe.get_traceback()}",
            title="Analytics Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def predict_kitchen_load(
    date: str,
    factors: Optional[List[str]] = None
) -> Dict:
    """
    Predict kitchen load for specific date
    
    Args:
        date: Date for prediction
        factors: Optional specific factors to consider
        
    Returns:
        Dict containing load predictions
    """
    try:
        validate_analytics_access("load_prediction")
        
        # Get historical data
        historical_data = get_historical_load_data(date)
        
        # Consider additional factors
        if factors:
            factor_data = analyze_load_factors(factors, date)
            historical_data = adjust_historical_data(
                historical_data,
                factor_data
            )
            
        # Generate predictions
        predictions = generate_load_predictions(historical_data)
        
        # Calculate confidence intervals
        confidence = calculate_prediction_confidence(predictions)
        
        return {
            "success": True,
            "date": date,
            "predictions": predictions,
            "confidence": confidence,
            "factors_considered": factors or [],
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Load Prediction Error: {str(e)}\n{frappe.get_traceback()}",
            title="Analytics Error"
        )
        return {"success": False, "error": str(e)}

def calculate_performance_metrics(
    base_data: Dict,
    metrics: List[str]
) -> Dict:
    """Calculate requested performance metrics"""
    result = {}
    
    for metric in metrics:
        if metric == AnalyticsMetrics.PREPARATION_TIME:
            result[metric] = calculate_prep_time_metrics(base_data)
        elif metric == AnalyticsMetrics.ORDER_ACCURACY:
            result[metric] = calculate_order_accuracy(base_data)
        elif metric == AnalyticsMetrics.STATION_EFFICIENCY:
            result[metric] = calculate_station_efficiency(base_data)
        elif metric == AnalyticsMetrics.RESOURCE_UTILIZATION:
            result[metric] = calculate_resource_utilization(base_data)
            
    return result

def analyze_performance_trends(base_data: Dict) -> Dict:
    """Analyze performance trends from base data"""
    daily_trends = calculate_daily_trends(base_data)
    weekly_trends = calculate_weekly_trends(base_data)
    monthly_trends = calculate_monthly_trends(base_data)
    
    return {
        "daily": daily_trends,
        "weekly": weekly_trends,
        "monthly": monthly_trends,
        "patterns": identify_patterns(daily_trends, weekly_trends, monthly_trends)
    }

def generate_load_predictions(historical_data: Dict) -> Dict:
    """Generate load predictions based on historical data"""
    hourly_predictions = predict_hourly_load(historical_data)
    station_predictions = predict_station_load(historical_data)
    
    return {
        "hourly": hourly_predictions,
        "by_station": station_predictions,
        "peak_times": predict_peak_times(hourly_predictions),
        "resource_requirements": calculate_resource_requirements(
            hourly_predictions,
            station_predictions
        )
    }