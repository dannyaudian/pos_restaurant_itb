# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
Table Status API
---------------
Manages table status and operations in the restaurant.

Features:
- Get table status (all or by section)
- Track table orders and queue
- Monitor table availability
- Handle table assignments
"""

__created_date__ = '2025-04-06 15:44:30'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List, Optional
from datetime import datetime, timedelta

from pos_restaurant_itb.utils.error_handlers import handle_api_error
from pos_restaurant_itb.utils.common import get_business_date
from pos_restaurant_itb.utils.security import validate_branch_operation

@frappe.whitelist()
@handle_api_error
def get_table_status(section: Optional[str] = None) -> Dict:
    """
    Get current status of all tables or by section
    
    Args:
        section: Optional section name to filter tables
        
    Returns:
        Dict containing:
            - success: Boolean indicating success/failure
            - tables: List of table details with orders and queue
            - last_updated: Timestamp of last update
            - section_info: Section details if section provided
    """
    try:
        # Validate branch access
        validate_branch_operation(
            branch=frappe.defaults.get_user_default("Branch"),
            operation="view_tables",
            user=frappe.session.user
        )
        
        # Build filters
        filters = {"section": section} if section else {}
        filters["disabled"] = 0  # Only get active tables
        
        # Get tables with details
        tables = frappe.get_all(
            "POS Table",
            filters=filters,
            fields=[
                "name", 
                "table_number",
                "capacity",
                "status",
                "current_order",
                "section",
                "floor",
                "last_order_time",
                "server_assigned"
            ]
        )
        
        # Enrich table data
        business_date = get_business_date()
        for table in tables:
            table.orders = get_table_orders(table.name, business_date)
            table.queue = get_queue_for_table(table.name)
            table.analytics = get_table_analytics(table.name)
            
        # Get section info if specified
        section_info = None
        if section:
            section_info = frappe.get_doc("Table Section", section)
            
        return {
            "success": True,
            "tables": tables,
            "section_info": section_info,
            "last_updated": frappe.utils.now(),
            "business_date": business_date
        }
    except Exception as e:
        frappe.log_error(
            message=f"Table Status Error: {str(e)}\n{frappe.get_traceback()}",
            title="Table Status Error"
        )
        return {
            "success": False,
            "error": str(e),
            "error_type": type(e).__name__
        }

def get_table_orders(table_name: str, business_date: datetime) -> List[Dict]:
    """Get orders for a specific table on business date"""
    return frappe.get_all(
        "POS Order",
        filters={
            "table": table_name,
            "docstatus": ["!=", 2],  # Not cancelled
            "business_date": business_date
        },
        fields=[
            "name",
            "status",
            "order_time",
            "total_items",
            "grand_total",
            "customer_name"
        ],
        order_by="creation desc"
    )

def get_queue_for_table(table_name: str) -> List[Dict]:
    """Get queue entries for a specific table"""
    return frappe.get_all(
        "Queue Entry",
        filters={
            "table_requested": table_name,
            "status": "Waiting"
        },
        fields=[
            "name",
            "customer_name",
            "pax",
            "wait_time",
            "queue_number",
            "creation"
        ],
        order_by="creation asc"
    )

def get_table_analytics(table_name: str) -> Dict:
    """Get analytics data for a specific table"""
    today = frappe.utils.today()
    
    # Get order counts
    total_orders = frappe.db.count(
        "POS Order",
        filters={
            "table": table_name,
            "creation": [">=", today]
        }
    )
    
    # Get revenue
    revenue = frappe.db.sql("""
        SELECT IFNULL(SUM(grand_total), 0)
        FROM `tabPOS Order`
        WHERE table = %s
        AND creation >= %s
        AND docstatus = 1
    """, (table_name, today))[0][0]
    
    # Get average dining time
    avg_dining_time = frappe.db.sql("""
        SELECT AVG(TIMESTAMPDIFF(MINUTE, order_time, completion_time))
        FROM `tabPOS Order`
        WHERE table = %s
        AND creation >= %s
        AND status = 'Completed'
    """, (table_name, today))[0][0] or 0
    
    return {
        "total_orders": total_orders,
        "revenue": revenue,
        "avg_dining_time": round(avg_dining_time, 2),
        "date": today
    }