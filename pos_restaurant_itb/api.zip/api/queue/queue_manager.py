# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
Queue Management API
------------------
Manages restaurant queuing system and wait time predictions.

Features:
- Queue entry management
- Wait time predictions
- Queue notifications
- Capacity management
- Priority handling
"""

__created_date__ = '2025-04-06 15:54:58'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta

from pos_restaurant_itb.utils.error_handlers import handle_api_error, QueueError
from pos_restaurant_itb.utils.constants import QueueStatus, NotificationChannel
from pos_restaurant_itb.utils.notifications import send_notification

@frappe.whitelist()
@handle_api_error
def create_queue_entry(
    customer_name: str,
    pax: int,
    contact_number: str,
    preferences: Optional[Dict] = None,
    priority: Optional[int] = None
) -> Dict:
    """
    Create new queue entry
    
    Args:
        customer_name: Name of the customer
        pax: Number of people
        contact_number: Customer contact number
        preferences: Optional seating preferences
        priority: Optional priority level
        
    Returns:
        Dict containing queue entry details
    """
    try:
        # Validate queue capacity
        validate_queue_capacity()
        
        # Validate inputs
        if pax <= 0:
            raise QueueError("Number of people must be greater than 0")
            
        if not contact_number:
            raise QueueError("Contact number is required for notifications")
            
        # Create queue entry
        queue_entry = frappe.get_doc({
            "doctype": "Queue Entry",
            "customer_name": customer_name,
            "pax": pax,
            "contact_number": contact_number,
            "preferences": frappe.as_json(preferences) if preferences else None,
            "priority": priority or 0,
            "status": QueueStatus.WAITING,
            "entry_time": frappe.utils.now(),
            "estimated_wait_time": calculate_wait_time(pax, preferences)
        })
        
        queue_entry.insert()
        
        # Send confirmation notification
        send_queue_confirmation(queue_entry)
        
        return {
            "success": True,
            "queue_number": queue_entry.name,
            "position": get_queue_position(queue_entry.name),
            "estimated_wait": queue_entry.estimated_wait_time,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Queue Entry Creation Error: {str(e)}\n{frappe.get_traceback()}",
            title="Queue Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def update_queue_status(
    queue_number: str,
    status: str,
    table: Optional[str] = None
) -> Dict:
    """
    Update queue entry status
    
    Args:
        queue_number: Queue entry number
        status: New status
        table: Optional table assignment
        
    Returns:
        Dict containing updated queue status
    """
    try:
        # Validate status
        if status not in QueueStatus.__members__:
            raise QueueError(f"Invalid status: {status}")
            
        # Get queue entry
        entry = frappe.get_doc("Queue Entry", queue_number)
        
        # Update status
        entry.status = status
        if status == QueueStatus.SEATED:
            if not table:
                raise QueueError("Table assignment required for seating")
            entry.table_assigned = table
            entry.seating_time = frappe.utils.now()
            
        elif status == QueueStatus.CALLED:
            entry.call_time = frappe.utils.now()
            
        entry.save()
        
        # Send notification
        notify_status_update(entry)
        
        # Update wait times for remaining queue
        update_wait_times()
        
        return {
            "success": True,
            "queue_number": queue_number,
            "status": status,
            "table": table,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Queue Status Update Error: {str(e)}\n{frappe.get_traceback()}",
            title="Queue Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def get_queue_status(
    queue_number: Optional[str] = None,
    status: Optional[str] = None
) -> Dict:
    """
    Get queue status and details
    
    Args:
        queue_number: Optional specific queue number
        status: Optional status filter
        
    Returns:
        Dict containing queue status details
    """
    try:
        filters = {}
        if queue_number:
            filters["name"] = queue_number
        if status:
            filters["status"] = status
            
        entries = frappe.get_all(
            "Queue Entry",
            filters=filters,
            fields=[
                "name",
                "customer_name",
                "pax",
                "status",
                "entry_time",
                "estimated_wait_time",
                "call_time",
                "seating_time",
                "table_assigned",
                "priority"
            ],
            order_by="priority desc, entry_time asc"
        )
        
        # Enrich with additional details
        for entry in entries:
            entry.position = get_queue_position(entry.name)
            entry.wait_time = get_current_wait_time(entry)
            
        return {
            "success": True,
            "entries": entries,
            "total_waiting": len([e for e in entries if e.status == QueueStatus.WAITING]),
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Queue Status Check Error: {str(e)}\n{frappe.get_traceback()}",
            title="Queue Error"
        )
        return {"success": False, "error": str(e)}

def validate_queue_capacity() -> None:
    """Validate if queue has capacity for new entries"""
    settings = frappe.get_single("POS Restaurant Config")
    current_size = frappe.db.count(
        "Queue Entry",
        {"status": QueueStatus.WAITING}
    )
    
    if current_size >= settings.max_queue_size:
        raise QueueError("Queue is at maximum capacity")

def calculate_wait_time(pax: int, preferences: Optional[Dict]) -> int:
    """Calculate estimated wait time in minutes"""
    base_time = get_base_wait_time()
    
    # Adjust for party size
    pax_factor = 1 + (pax / 10)  # 10% increase per person
    
    # Adjust for preferences
    pref_factor = calculate_preference_factor(preferences)
    
    # Adjust for current load
    load_factor = get_current_load_factor()
    
    return int(base_time * pax_factor * pref_factor * load_factor)

def notify_status_update(entry: "Queue Entry") -> None:
    """Send status update notification"""
    settings = frappe.get_single("POS Restaurant Config")
    
    message = get_status_message(entry)
    
    if settings.notification_method == NotificationChannel.SMS:
        send_notification(
            channel="sms",
            to=entry.contact_number,
            message=message
        )
    elif settings.notification_method == NotificationChannel.EMAIL:
        send_notification(
            channel="email",
            to=entry.email,
            subject="Queue Status Update",
            message=message
        )
    elif settings.notification_method == NotificationChannel.WHATSAPP:
        send_notification(
            channel="whatsapp",
            to=entry.contact_number,
            message=message
        )