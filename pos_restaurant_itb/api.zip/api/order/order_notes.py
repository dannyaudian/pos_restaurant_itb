# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
Order Notes API
-------------
Manages order notes, modifications, and special requests.

Features:
- Order notes management
- Special requests tracking
- Modification history
- Kitchen instructions
- Customer preferences
"""

__created_date__ = '2025-04-06 16:00:58'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List, Optional, Union
from datetime import datetime, timedelta

from pos_restaurant_itb.utils.error_handlers import handle_api_error, NoteError
from pos_restaurant_itb.utils.security import validate_note_permission
from pos_restaurant_itb.utils.constants import NoteType, NoteVisibility

@frappe.whitelist()
@handle_api_error
def add_order_note(
    order_id: str,
    note: str,
    note_type: str,
    visibility: str = NoteVisibility.ALL,
    attachment: Optional[str] = None
) -> Dict:
    """
    Add note to order
    
    Args:
        order_id: POS Order ID
        note: Note content
        note_type: Type of note
        visibility: Note visibility level
        attachment: Optional attachment URL
        
    Returns:
        Dict containing note details
    """
    try:
        # Validate permissions
        validate_note_permission("create")
        
        # Validate note type
        if note_type not in NoteType.__members__:
            raise NoteError(f"Invalid note type: {note_type}")
            
        # Validate visibility
        if visibility not in NoteVisibility.__members__:
            raise NoteError(f"Invalid visibility level: {visibility}")
            
        # Create note
        order_note = frappe.get_doc({
            "doctype": "Order Note",
            "order": order_id,
            "note": note,
            "note_type": note_type,
            "visibility": visibility,
            "attachment": attachment,
            "created_by": frappe.session.user,
            "creation_time": frappe.utils.now()
        })
        order_note.insert()
        
        # Update order
        update_order_notes(order_id)
        
        # Notify relevant parties
        notify_note_creation(order_note)
        
        return {
            "success": True,
            "note_id": order_note.name,
            "order_id": order_id,
            "timestamp": frappe.utils.now(),
            "created_by": frappe.session.user
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Order Note Creation Error: {str(e)}\n{frappe.get_traceback()}",
            title="Note Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def update_order_note(
    note_id: str,
    note: Optional[str] = None,
    visibility: Optional[str] = None,
    attachment: Optional[str] = None
) -> Dict:
    """
    Update existing order note
    
    Args:
        note_id: Note ID
        note: Updated note content
        visibility: Updated visibility level
        attachment: Updated attachment URL
        
    Returns:
        Dict containing updated note details
    """
    try:
        # Validate permissions
        validate_note_permission("update")
        
        # Get note
        order_note = frappe.get_doc("Order Note", note_id)
        
        # Validate update permission
        if not can_update_note(order_note):
            raise NoteError("You don't have permission to update this note")
            
        # Update note
        if note:
            order_note.note = note
        if visibility:
            if visibility not in NoteVisibility.__members__:
                raise NoteError(f"Invalid visibility level: {visibility}")
            order_note.visibility = visibility
        if attachment:
            order_note.attachment = attachment
            
        order_note.modified_by = frappe.session.user
        order_note.modified = frappe.utils.now()
        order_note.save()
        
        # Update order
        update_order_notes(order_note.order)
        
        # Notify update
        notify_note_update(order_note)
        
        return {
            "success": True,
            "note_id": note_id,
            "order_id": order_note.order,
            "timestamp": frappe.utils.now(),
            "modified_by": frappe.session.user
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Order Note Update Error: {str(e)}\n{frappe.get_traceback()}",
            title="Note Error"
        )
        return {"success": False, "error": str(e)}

@frappe.whitelist()
@handle_api_error
def get_order_notes(
    order_id: str,
    note_type: Optional[str] = None,
    visibility: Optional[str] = None
) -> Dict:
    """
    Get notes for specific order
    
    Args:
        order_id: POS Order ID
        note_type: Optional note type filter
        visibility: Optional visibility filter
        
    Returns:
        Dict containing order notes
    """
    try:
        # Build filters
        filters = {"order": order_id}
        if note_type:
            if note_type not in NoteType.__members__:
                raise NoteError(f"Invalid note type: {note_type}")
            filters["note_type"] = note_type
        if visibility:
            if visibility not in NoteVisibility.__members__:
                raise NoteError(f"Invalid visibility level: {visibility}")
            filters["visibility"] = visibility
            
        # Get notes
        notes = frappe.get_all(
            "Order Note",
            filters=filters,
            fields=[
                "name",
                "note",
                "note_type",
                "visibility",
                "attachment",
                "created_by",
                "creation_time",
                "modified_by",
                "modified"
            ],
            order_by="creation_time desc"
        )
        
        # Enrich notes with user details
        for note in notes:
            note.user_details = get_user_details(note.created_by)
            if note.modified_by:
                note.modifier_details = get_user_details(note.modified_by)
                
        return {
            "success": True,
            "order_id": order_id,
            "notes": notes,
            "timestamp": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Get Order Notes Error: {str(e)}\n{frappe.get_traceback()}",
            title="Note Error"
        )
        return {"success": False, "error": str(e)}

def can_update_note(note: "Order Note") -> bool:
    """Check if current user can update note"""
    if frappe.session.user == note.created_by:
        return True
        
    return frappe.has_permission(
        "Order Note",
        "write",
        doc=note
    )

def notify_note_creation(note: "Order Note") -> None:
    """Send notifications for new note"""
    # Notify POS
    frappe.publish_realtime(
        "order_note_added",
        {
            "order_id": note.order,
            "note_id": note.name,
            "note_type": note.note_type
        }
    )
    
    # Notify kitchen if applicable
    if note.note_type in [NoteType.KITCHEN, NoteType.MODIFICATION]:
        notify_kitchen_note(note)
        
    # Notify staff based on visibility
    notify_staff(note)

def get_user_details(user: str) -> Dict:
    """Get user details for note attribution"""
    return frappe.db.get_value(
        "User",
        user,
        ["full_name", "user_image"],
        as_dict=True
    )