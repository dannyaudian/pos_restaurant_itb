# Copyright (c) 2024, PT. Innovasi Terbaik Bangsa and contributors
# For license information, please see license.txt

"""
Order Analytics API
-----------------
Comprehensive analytics for order management and performance tracking.

Features:
- Order performance metrics
- Sales analytics
- Customer behavior analysis
- Menu performance tracking
- Revenue insights
"""

__created_date__ = '2025-04-06 15:48:01'
__author__ = 'dannyaudian'
__owner__ = 'PT. Innovasi Terbaik Bangsa'

import frappe
from frappe import _
from typing import Dict, List, Optional, Union
from datetime import datetime, timedelta

from pos_restaurant_itb.utils.error_handlers import handle_api_error, AnalyticsError
from pos_restaurant_itb.utils.common import get_business_date
from pos_restaurant_itb.utils.constants import OrderStatus, PaymentStatus

@frappe.whitelist()
@handle_api_error
def get_order_metrics(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    branch: Optional[str] = None
) -> Dict:
    """
    Get comprehensive order metrics
    
    Args:
        start_date: Analysis start date (defaults to today)
        end_date: Analysis end date (defaults to today)
        branch: Optional branch filter
        
    Returns:
        Dict containing order metrics and analytics
    """
    try:
        # Set default dates
        start_date = start_date or frappe.utils.today()
        end_date = end_date or start_date
        
        # Build base filters
        filters = {
            "creation": ["between", [start_date, end_date]],
            "docstatus": 1  # Only submitted orders
        }
        if branch:
            filters["branch"] = branch
            
        # Get basic metrics
        basic_metrics = get_basic_metrics(filters)
        
        # Get detailed analytics
        return {
            "success": True,
            "start_date": start_date,
            "end_date": end_date,
            "branch": branch,
            "basic_metrics": basic_metrics,
            "hourly_distribution": get_hourly_distribution(filters),
            "payment_analytics": get_payment_analytics(filters),
            "menu_performance": get_menu_performance(filters),
            "table_analytics": get_table_analytics(filters),
            "customer_insights": get_customer_insights(filters),
            "generated_at": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Order Metrics Error: {str(e)}\n{frappe.get_traceback()}",
            title="Order Analytics Error"
        )
        return {"success": False, "error": str(e)}

def get_basic_metrics(filters: Dict) -> Dict:
    """Get basic order metrics"""
    total_orders = frappe.db.count("POS Order", filters)
    
    # Get revenue metrics
    revenue_data = frappe.db.sql("""
        SELECT 
            COUNT(*) as order_count,
            SUM(grand_total) as total_revenue,
            AVG(grand_total) as avg_order_value,
            SUM(total_quantity) as total_items,
            COUNT(DISTINCT customer) as unique_customers
        FROM `tabPOS Order`
        WHERE creation BETWEEN %(start)s AND %(end)s
        AND branch = %(branch)s
        AND docstatus = 1
    """, filters, as_dict=1)[0]
    
    # Get status distribution
    status_dist = frappe.db.sql("""
        SELECT 
            status,
            COUNT(*) as count,
            AVG(TIMESTAMPDIFF(MINUTE, order_time, modified)) as avg_completion_time
        FROM `tabPOS Order`
        WHERE creation BETWEEN %(start)s AND %(end)s
        AND branch = %(branch)s
        GROUP BY status
    """, filters, as_dict=1)
    
    return {
        "total_orders": total_orders,
        "revenue_data": revenue_data,
        "status_distribution": status_dist
    }

@frappe.whitelist()
@handle_api_error
def get_menu_performance(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    limit: int = 10
) -> Dict:
    """
    Get menu item performance analytics
    
    Args:
        start_date: Start date for analysis
        end_date: End date for analysis
        limit: Number of top items to return
        
    Returns:
        Dict containing menu performance metrics
    """
    try:
        # Set default dates
        start_date = start_date or frappe.utils.today()
        end_date = end_date or start_date
        
        # Get top selling items
        top_items = frappe.db.sql("""
            SELECT 
                item_code,
                item_name,
                SUM(quantity) as total_quantity,
                SUM(amount) as total_amount,
                COUNT(DISTINCT parent) as order_count,
                AVG(rate) as avg_rate
            FROM `tabPOS Order Item`
            WHERE creation BETWEEN %s AND %s
            GROUP BY item_code
            ORDER BY total_quantity DESC
            LIMIT %s
        """, (start_date, end_date, limit), as_dict=1)
        
        # Get category performance
        category_perf = frappe.db.sql("""
            SELECT 
                item_group as category,
                COUNT(*) as item_count,
                SUM(quantity) as total_quantity,
                SUM(amount) as total_amount
            FROM `tabPOS Order Item`
            WHERE creation BETWEEN %s AND %s
            GROUP BY item_group
            ORDER BY total_amount DESC
        """, (start_date, end_date), as_dict=1)
        
        # Calculate additional metrics
        for item in top_items:
            item.update(calculate_item_metrics(item.item_code, start_date, end_date))
            
        return {
            "success": True,
            "start_date": start_date,
            "end_date": end_date,
            "top_items": top_items,
            "category_performance": category_perf,
            "generated_at": frappe.utils.now()
        }
        
    except Exception as e:
        frappe.log_error(
            message=f"Menu Performance Error: {str(e)}\n{frappe.get_traceback()}",
            title="Menu Analytics Error"
        )
        return {"success": False, "error": str(e)}

def calculate_item_metrics(
    item_code: str,
    start_date: str,
    end_date: str
) -> Dict:
    """Calculate detailed metrics for a specific item"""
    # Get peak hours for the item
    peak_hours = frappe.db.sql("""
        SELECT 
            HOUR(creation) as hour,
            COUNT(*) as order_count
        FROM `tabPOS Order Item`
        WHERE item_code = %s
        AND creation BETWEEN %s AND %s
        GROUP BY HOUR(creation)
        ORDER BY order_count DESC
        LIMIT 3
    """, (item_code, start_date, end_date), as_dict=1)
    
    # Get modification frequency
    mods = frappe.db.sql("""
        SELECT 
            COUNT(*) as total_mods,
            COUNT(DISTINCT parent) as orders_with_mods
        FROM `tabPOS Order Item`
        WHERE item_code = %s
        AND creation BETWEEN %s AND %s
        AND modifications IS NOT NULL
    """, (item_code, start_date, end_date), as_dict=1)[0]
    
    return {
        "peak_hours": peak_hours,
        "modification_stats": mods,
        "prep_time": get_item_prep_time(item_code, start_date, end_date)
    }

def get_item_prep_time(
    item_code: str,
    start_date: str,
    end_date: str
) -> Dict:
    """Get preparation time statistics for an item"""
    return frappe.db.sql("""
        SELECT 
            AVG(preparation_time) as avg_prep_time,
            MIN(preparation_time) as min_prep_time,
            MAX(preparation_time) as max_prep_time,
            COUNT(*) as sample_size
        FROM `tabKitchen Display Order Item`
        WHERE item_code = %s
        AND creation BETWEEN %s AND %s
        AND status = 'Completed'
    """, (item_code, start_date, end_date), as_dict=1)[0]